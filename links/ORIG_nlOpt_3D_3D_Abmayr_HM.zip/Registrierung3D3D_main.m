
%% ---------------------
% Prof. Dr. Thomas Abmayr
% Fakult�t f�r Geoinformation
% Hochschule M�nchen
%% ---------------------

function [  ] = Registrierung3D3D(  )

clc;
clear all;
close all;

load('finalErr.mat');
load('initVals.mat'); 
clear finalError;
clear initValues;

%% 2.) Datenstruktur definieren

data(1,:,:) = [
    12.207285,  0.616825,  4.706454; 
    0,  0,  0;
    5.971618, -8.391790,  4.626923;   
	1.543923,  0.971698, -0.727905;      
	-1.398976, -6.680445,  0.276694;      
	-3.060644, -2.589179, -0.804931];    
 
data(2,:,:) = [ 
    12.121424, -6.177644,  4.486624;    
	7.531156, -7.838682,  4.566603;    
	1.826167, -9.888171,  4.662243;   
	3.549575, 0.275690, -0.799391;      
	-3.270373, -4.231822,  0.387421;      
	-2.268084,  0.055922, -0.744826];    
 
data(3,:,:) = [ 
	11.445148,  5.262337,  4.597735;    
	10.868797,  0.405053,  4.609394;    
	10.141868, -5.609702,  4.630785;    
	1.822835,  0.541238, -0.734484;      
	2.805144, -7.587795,  0.340796;      
	-0.582772, -4.761177, -0.748867];    
 
data(4,:,:) = [ 
	14.218289, -0.032720,  4.295927;    
	11.059488, -3.758462,  4.380108;    
	7.101966, -8.366411,  4.464961;    
	3.491574,  1.351804, -0.824512;      
	-0.165618, -5.964227,  0.335353;      
	-1.445559, -1.733071, -0.733188];    
 


%% 3.) Startwerte berechnen
R(:,:,1) = eye(3);
initValues = [];
for i=2:4
    P(:,:) = data(i,:,:);
    Q(:,:) = data(1,:,:);
	[r,p,y,tx,ty,tz] = Reg_3D_3D_init( P, Q );
    initValues = [initValues,r,p,y,tx,ty,tz]; 
    
end


f = @(x) errFct( x, data);

%options = optimset('MaxFunEvals',10000, 'TolFun', 1e-10, 'MaxIter', 4);
options = optimset( 'MaxFunEvals',4);
% x_optimized = lsqnonlin(f, initValues, [], [], options);
x_optimized = fminsearch(f, initValues, options);

err = Reg_3D_3D_statistics( x_optimized, data );

N = 1;
for i=1 : 4
    for k=1 : 6
        a = [err(i,k,1), err(i,k,2), err(i,k,3)];
        finalError(N,1:3) = a';
        N = N+1;
    end
end;

save('initVals.mat', 'initValues'); 
save('finalErr.mat', 'finalError');
